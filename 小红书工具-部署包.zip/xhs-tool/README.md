# 小红书图文排版工具

一个帮助小红书创作者快速生成爆款笔记的工具，支持AI文案生成和AI配图。

## ✨ 功能特性

- 📝 **一键生成7套爆款文案**（5套本地 + 2套AI生成）
- 🎨 **AI生成配图**（支持9种风格：摄影/3D卡通/动画/油画/水彩/素描/国画/扁平插画/人像写真）
- 📐 **多种排版模板**（3:4竖版/1:1方图/4:3横版）
- 📥 **导出PNG图片**
- 📋 **一键复制文案**

## 🚀 本地使用

### 环境要求
- Node.js 18.x 或更高版本

### 启动步骤
1. 安装依赖：
   ```bash
   npm install
   ```

2. 启动服务：
   ```bash
   node server.js
   ```

3. 打开浏览器访问：http://localhost:7788

### API Key 配置
在 `server.js` 第22行修改 DashScope API Key：
```javascript
const DASHSCOPE_API_KEY = process.env.DASHSCOPE_API_KEY || '你的API Key';
```

获取 API Key：https://dashscope.aliyun.com/

## ☁️ 免费部署到互联网

### 方法一：Render.com（推荐，完全免费）
详细步骤请查看 `部署教学.md`

**快速步骤**：
1. 注册 GitHub 和 Render.com 账号
2. 上传代码到 GitHub
3. 在 Render.com 创建 Web Service
4. 配置环境变量 `DASHSCOPE_API_KEY`
5. 获得永久访问链接（如：`https://xhs-tool.onrender.com`）

**免费版限制**：
- 15分钟无访问会自动休眠（下次访问需等待30秒唤醒）
- 每天最多运行750小时（足够个人使用）

### 方法二：本地分享（局域网）
1. 启动服务：`node server.js`
2. 查看本机IP地址：
   - Mac/Linux：`ifconfig | grep inet`
   - Windows：`ipconfig`
3. 告诉同一局域网的朋友访问：`http://你的IP:7788`

## 📋 文件说明

```
xhs-tool/
├── server.js          # 后端服务（Node.js）
├── index.html         # 前端页面
├── package.json       # 项目配置
├── render.yaml        # Render.com 部署配置
├── README.md         # 本文件
├── 部署教学.md        # Render.com 部署详细教程
└── 启动.command       # Mac 启动脚本（双击即用）
```

## 🛠️ 技术栈

- **前端**：HTML + CSS + JavaScript（无框架，纯原生）
- **后端**：Node.js（HTTP 模块，无框架）
- **AI 服务**：
  - 阿里通义万相（图片生成）
  - 阿里通义千问（文案生成）

## ⚠️ 注意事项

1. **API Key 安全**：不要将包含 API Key 的代码上传到公开仓库
2. **免费额度**：DashScope 免费额度为每日500次调用，请注意使用量
3. **休眠问题**：Render.com 免费版会休眠，这是正常现象

## 📞 技术支持

如遇问题，请查看：
- `部署教学.md`（部署相关）
- Render.com 日志（服务页面 → Logs 标签）
- GitHub Issues（如果有的话）

## 📄 许可证

MIT License

---

**版本**：v7（通义万相版）  
**更新日期**：2026-04-18
