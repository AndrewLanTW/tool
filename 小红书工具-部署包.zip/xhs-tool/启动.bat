@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

echo ========================================
echo  小红书图文工具 - 启动中...
echo ========================================

REM Check if node exists
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Node.js not found! Please install Node.js first.
    echo Download: https://nodejs.org/zh-cn
    pause
    exit /b 1
)

REM Install dependencies if node_modules not exists
if not exist "node_modules\" (
    echo [INFO] Installing dependencies... Please wait...
    call npm install
    if %errorlevel% neq 0 (
        echo [ERROR] Installation failed! Please check network connection.
        pause
        exit /b 1
    )
)

REM Start server
echo [INFO] Starting server...
start "" http://localhost:7788/
node server.js

pause
