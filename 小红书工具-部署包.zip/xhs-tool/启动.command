#!/bin/bash

# 小红书图文排版工具 - Mac 启动脚本
# 双击此文件即可启动工具

echo "正在启动小红书图文排版工具..."

# 获取脚本所在目录
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

# 检查 Node.js 是否安装
if ! command -v node &> /dev/null; then
    echo "错误：未检测到 Node.js！"
    echo "请先安装 Node.js：https://nodejs.org/zh-cn"
    echo ""
    echo "按任意键退出..."
    read -n 1
    exit 1
fi

echo "Node.js 版本：$(node -v)"
echo "正在启动服务器..."

# 启动服务器
node server.js &

# 等待服务器启动
sleep 3

# 打开浏览器
echo "正在打开浏览器..."
open http://localhost:7788

# 保持终端窗口打开
echo ""
echo "✅ 服务器已启动！"
echo "   浏览器已打开：http://localhost:7788"
echo ""
echo "提示：关闭此窗口将停止服务器"
echo "按 Ctrl+C 停止服务器"
echo ""

# 等待（保持脚本运行）
wait
